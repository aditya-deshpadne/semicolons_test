"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'helloWorld';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'Hello_World';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJQTFVHSU5fTkFNRSJdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAnaGVsbG9Xb3JsZCc7XG5leHBvcnQgY29uc3QgUExVR0lOX05BTUUgPSAnSGVsbG9fV29ybGQnO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBTyxNQUFNQSxTQUFTLEdBQUcsWUFBWTtBQUFDO0FBQy9CLE1BQU1DLFdBQVcsR0FBRyxhQUFhO0FBQUMifQ==