"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defineRoutes = defineRoutes;
var _elasticsearch = require("@elastic/elasticsearch");
//const client = new Client({ node: 'https://elastic:elastic@localhost:9200' })
const client = new _elasticsearch.Client({
  node: 'https://localhost:9200',
  auth: {
    username: 'elastic',
    password: 'elastic'
  },
  tls: {
    // might be required if it's a self-signed certificate
    rejectUnauthorized: false
  }
});
function defineRoutes(router) {
  router.get({
    path: '/api/hello_world/example',
    validate: false
  }, async (context, request, response) => {
    return response.ok({
      body: {
        time: new Date().toISOString()
      }
    });
  });
  router.get({
    path: '/api/hello_world/test',
    validate: false
  }, async (context, request, response) => {
    const result = await client.search({
      index: 'game-of-thrones',
      query: {
        match_all: {}
      }
    }, {
      meta: true
    });
    console.log("-----ADYA-----" + JSON.stringify(result.body.hits.hits));
    return response.ok({
      body: {
        hits: JSON.stringify(result.body.hits.hits)
      }
    });
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJjbGllbnQiLCJDbGllbnQiLCJub2RlIiwiYXV0aCIsInVzZXJuYW1lIiwicGFzc3dvcmQiLCJ0bHMiLCJyZWplY3RVbmF1dGhvcml6ZWQiLCJkZWZpbmVSb3V0ZXMiLCJyb3V0ZXIiLCJnZXQiLCJwYXRoIiwidmFsaWRhdGUiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwib2siLCJib2R5IiwidGltZSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInJlc3VsdCIsInNlYXJjaCIsImluZGV4IiwicXVlcnkiLCJtYXRjaF9hbGwiLCJtZXRhIiwiY29uc29sZSIsImxvZyIsIkpTT04iLCJzdHJpbmdpZnkiLCJoaXRzIl0sInNvdXJjZXMiOlsiaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSVJvdXRlciB9IGZyb20gJy4uLy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5cbmltcG9ydCB7IENsaWVudCwgQXBpUmVzcG9uc2UsIFJlcXVlc3RQYXJhbXMgfSBmcm9tICdAZWxhc3RpYy9lbGFzdGljc2VhcmNoJ1xuLy9jb25zdCBjbGllbnQgPSBuZXcgQ2xpZW50KHsgbm9kZTogJ2h0dHBzOi8vZWxhc3RpYzplbGFzdGljQGxvY2FsaG9zdDo5MjAwJyB9KVxuY29uc3QgY2xpZW50ID0gbmV3IENsaWVudCh7XG4gIG5vZGU6ICdodHRwczovL2xvY2FsaG9zdDo5MjAwJyxcbiAgYXV0aDogeyBcblx0ICB1c2VybmFtZTogJ2VsYXN0aWMnLFxuXHQgIHBhc3N3b3JkOiAnZWxhc3RpYydcbiAgfSxcbiAgdGxzOiB7XG4gICAgLy8gbWlnaHQgYmUgcmVxdWlyZWQgaWYgaXQncyBhIHNlbGYtc2lnbmVkIGNlcnRpZmljYXRlXG4gICAgcmVqZWN0VW5hdXRob3JpemVkOiBmYWxzZVxuICB9XG59KVxuXG5leHBvcnQgZnVuY3Rpb24gZGVmaW5lUm91dGVzKHJvdXRlcjogSVJvdXRlcikge1xuXHRcbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9oZWxsb193b3JsZC9leGFtcGxlJyxcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHRpbWU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2hlbGxvX3dvcmxkL3Rlc3QnLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgIH0sXG4gICAgYXN5bmMoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICBjb25zdCByZXN1bHQgPWF3YWl0IGNsaWVudC5zZWFyY2goe1xuICBcdGluZGV4OiAnZ2FtZS1vZi10aHJvbmVzJyxcbiAgXHRxdWVyeToge1xuICAgIFx0XHRtYXRjaF9hbGw6e31cbiAgXHR9XG5cdH0sIHsgbWV0YTogdHJ1ZSB9KVxuXHRjb25zb2xlLmxvZyhcIi0tLS0tQURZQS0tLS0tXCIrSlNPTi5zdHJpbmdpZnkocmVzdWx0LmJvZHkuaGl0cy5oaXRzKSlcblx0cmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIGhpdHM6IEpTT04uc3RyaW5naWZ5KHJlc3VsdC5ib2R5LmhpdHMuaGl0cylcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuXHRcbiAgICB9KTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUE7QUFDQTtBQUNBLE1BQU1BLE1BQU0sR0FBRyxJQUFJQyxxQkFBTSxDQUFDO0VBQ3hCQyxJQUFJLEVBQUUsd0JBQXdCO0VBQzlCQyxJQUFJLEVBQUU7SUFDTEMsUUFBUSxFQUFFLFNBQVM7SUFDbkJDLFFBQVEsRUFBRTtFQUNYLENBQUM7RUFDREMsR0FBRyxFQUFFO0lBQ0g7SUFDQUMsa0JBQWtCLEVBQUU7RUFDdEI7QUFDRixDQUFDLENBQUM7QUFFSyxTQUFTQyxZQUFZLENBQUNDLE1BQWUsRUFBRTtFQUU1Q0EsTUFBTSxDQUFDQyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFLDBCQUEwQjtJQUNoQ0MsUUFBUSxFQUFFO0VBQ1osQ0FBQyxFQUNELE9BQU9DLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsT0FBT0EsUUFBUSxDQUFDQyxFQUFFLENBQUM7TUFDakJDLElBQUksRUFBRTtRQUNKQyxJQUFJLEVBQUUsSUFBSUMsSUFBSSxFQUFFLENBQUNDLFdBQVc7TUFDOUI7SUFDRixDQUFDLENBQUM7RUFDSixDQUFDLENBQ0Y7RUFFRFgsTUFBTSxDQUFDQyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFLHVCQUF1QjtJQUM3QkMsUUFBUSxFQUFFO0VBQ1osQ0FBQyxFQUNELE9BQU1DLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDckMsTUFBTU0sTUFBTSxHQUFFLE1BQU1yQixNQUFNLENBQUNzQixNQUFNLENBQUM7TUFDbkNDLEtBQUssRUFBRSxpQkFBaUI7TUFDeEJDLEtBQUssRUFBRTtRQUNKQyxTQUFTLEVBQUMsQ0FBQztNQUNkO0lBQ0YsQ0FBQyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFLLENBQUMsQ0FBQztJQUNsQkMsT0FBTyxDQUFDQyxHQUFHLENBQUMsZ0JBQWdCLEdBQUNDLElBQUksQ0FBQ0MsU0FBUyxDQUFDVCxNQUFNLENBQUNKLElBQUksQ0FBQ2MsSUFBSSxDQUFDQSxJQUFJLENBQUMsQ0FBQztJQUNuRSxPQUFPaEIsUUFBUSxDQUFDQyxFQUFFLENBQUM7TUFDWkMsSUFBSSxFQUFFO1FBQ0pjLElBQUksRUFBRUYsSUFBSSxDQUFDQyxTQUFTLENBQUNULE1BQU0sQ0FBQ0osSUFBSSxDQUFDYyxJQUFJLENBQUNBLElBQUk7TUFDNUM7SUFDRixDQUFDLENBQUM7RUFFSixDQUFDLENBQUM7QUFDTiJ9