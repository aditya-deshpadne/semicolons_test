"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'helloWrold792';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'HelloWrold7.9.2';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJQTFVHSU5fTkFNRSJdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAnaGVsbG9Xcm9sZDc5Mic7XG5leHBvcnQgY29uc3QgUExVR0lOX05BTUUgPSAnSGVsbG9Xcm9sZDcuOS4yJztcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQU8sTUFBTUEsU0FBUyxHQUFHLGVBQWU7QUFBQztBQUNsQyxNQUFNQyxXQUFXLEdBQUcsaUJBQWlCO0FBQUMifQ==